# Library Management System



# Programming Language and Tools

  - HTML
  - CSS
  - JavaScript
  - Firebase
  - Firestore
---
# How to check
1. clone the Repo or download Zip file
2. open index.html
3. for admin use 
- Username : admin@gmail.com
- Password : admin@123

4. for user account register a new user
---

# direct link 

https://rajpra786.github.io/Library-Management-System/index.html

---
# Contributors
- ##### Rajendra Prajapat
- ##### Dheeraj Chaudhary
- ##### Priya Tiru
- ##### Rajdeep Das
- ##### Shashank N S

##### Supervised By- Prof. Channappa B AKKI
###### Academic Year: 2018-2019